package com.automation.steps;

import com.automation.pages.ProductPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class ProductSteps {

    ProductPage productPage = new ProductPage();

    @Then("Print the description and price of the product")
    public void printTheDescriptionAndPriceOfTheProduct() {
        productPage.printDetails();
    }

    @And("add the product to cart")
    public void addTheProductToCart() {
        productPage.addToCart();
    }

    @And("verify user is on product page")
    public void verifyUserIsOnProductPage() {
        Assert.assertTrue(productPage.isPageDisplayed());
    }

    @Then("verify cart quantity equals to {string}")
    public void verifyCartQuantityEqualsTo(String qty) {
        Assert.assertEquals(qty, productPage.getCartQty());
    }

    @When("user clicks on cart button")
    public void userClicksOnCartButton() {
        productPage.clickOnCartBtn();
    }
}
