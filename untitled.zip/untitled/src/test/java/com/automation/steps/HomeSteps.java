package com.automation.steps;

import com.automation.pages.HomePage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class HomeSteps {

    HomePage homePage = new HomePage();

    @Given("when user opens the website")
    public void whenUserOpensTheWebsite() {
        homePage.openWebsite();
    }

    @Then("verify user is on the home page")
    public void verifyUserIsOnTheHomePage() {
        Assert.assertTrue(homePage.isPageDisplayed());
    }


    @When("user searches the product named {string}")
    public void userSearchesTheProductNamed(String key) {
        homePage.clickOnSearch(key);
    }
}
