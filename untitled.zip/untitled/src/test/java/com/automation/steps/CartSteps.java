package com.automation.steps;

import com.automation.pages.CartPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.Assert;

public class CartSteps {

    CartPage cartPage = new CartPage();

    @Then("verify the descriptions are same")
    public void verifyTheDescriptionsAreSame() {
        Assert.assertTrue(cartPage.verifyTheDetails());
    }

    @And("increase the quantity to {int}")
    public void increaseTheQuantityTo(int no) {
        cartPage.addQty(no);
    }

    @Then("verify whether the price is changed or not")
    public void verifyWhetherThePriceIsChangedOrNot() {
        cartPage.verifyPriceAfterIncrement();
    }

    @Then("verify user is on cart page")
    public void verifyUserIsOnCartPage() {
        Assert.assertTrue(cartPage.isPageDisplayed());
    }
}
