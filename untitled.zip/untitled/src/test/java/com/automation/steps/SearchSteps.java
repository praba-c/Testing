package com.automation.steps;

import com.automation.pages.SearchPage;
import io.cucumber.java.en.And;

public class SearchSteps {

    SearchPage searchPage = new SearchPage();

    @And("select the product containing the keyword {string}")
    public void selectTheProductContainingTheKeyword(String keyW) {
        searchPage.findProduct(keyW);
    }
}
