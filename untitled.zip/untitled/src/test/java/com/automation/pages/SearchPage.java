package com.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class SearchPage extends BasePage{

    public void findProduct(String keyW) {
        List<WebElement> elements = driver.findElements(
                By.xpath("//a[@class = 'st-title st-text-[#000000]']//span"));
        for (WebElement element : elements) {
            if (element.getText().contains(keyW)) {
                element.click();
                break;
            }
        }
    }
}
