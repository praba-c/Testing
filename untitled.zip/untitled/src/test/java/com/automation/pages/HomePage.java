package com.automation.pages;

import com.automation.utils.ConfigReader;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;


public class HomePage extends BasePage{

    @FindBy(xpath = "//div//input[@name='st']")
    WebElement main;

    @FindBy(xpath = "(//div/input[@name='st'])[1]")
    WebElement searchBar;

    public void openWebsite() {
        driver.get(ConfigReader.getProperties("url"));
    }

    public boolean isPageDisplayed() {
        return main.isDisplayed();
    }

    public void clickOnSearch(String key) {
        WebElement iframe = driver.findElement(By.id("iframe-kp"));
        driver.switchTo().frame(iframe);
        WebElement closeBtn = driver.findElement(By.id("close_button"));
        wait.until(ExpectedConditions.elementToBeClickable(closeBtn));
        closeBtn.click();
        driver.switchTo().defaultContent();
        searchBar.click();
        searchBar.sendKeys(key);
        searchBar.sendKeys(Keys.RETURN);
    }
}
