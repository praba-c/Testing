package com.automation.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class ProductPage extends BasePage{

    @FindBy(xpath = "(//h1[@class = 'product-title h5'])[2]")
    WebElement title;

    @FindBy(xpath = "(//div[@class = 'advantages'])[2]")
    WebElement description;

    @FindBy(xpath = "//div[@class = 'price']//div//strong//span")
    WebElement price;

    @FindBy(xpath = "//button[@class = 'btn btn--secondary w-full']")
    WebElement addToCartBtn;

    @FindBy(xpath = "//div[@id = 'cart-icon-bubble']//div//span")
    WebElement cartQty;

    public void printDetails() {
        tit = (title.getText());
        System.out.println(tit);
        desc = (description.getText());
        System.out.println(desc);
        pri = (price.getText());
        System.out.println(pri);
    }

    public void addToCart() {
        addToCartBtn.click();
    }

    public boolean isPageDisplayed() {
        wait.until(ExpectedConditions.visibilityOf(title));
        return title.isDisplayed();
    }

    public String getCartQty() {
        return cartQty.getText();
    }

    public void clickOnCartBtn() {
        cartQty.click();
    }
}
