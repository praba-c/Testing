package com.automation.pages;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CartPage extends BasePage{

    @FindBy(xpath = "//div[@class = 'title_opt']//a")
    WebElement title;

    @FindBy(xpath = "//div[@class = 'price__default']//strong//span")
    WebElement price;

    @FindBy(xpath = "(//button[@class = 'qty-input__btn btn btn--plus no-js-hidden'])")
    WebElement plusBtn;

    @FindBy(xpath = "(//dd[@class='price__current m-0 font-bold']//span)[2]")
    WebElement priceAfterInc;

    public boolean verifyTheDetails() {
        return (title.getText().equals(tit)) && (price.getText().equals(pri));
    }

    public void addQty(int no) {
        for (int i=1;i<no;++i) {
            plusBtn.click();
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void verifyPriceAfterIncrement() {
        String price = priceAfterInc.getText().replace("₹", " ").trim();
        double val = Double.parseDouble(price);
        double orgVal = Double.parseDouble(pri.replace("₹", " ").trim());

        System.out.println("Difference in price: " + (orgVal*3 - val));
    }

    public boolean isPageDisplayed() {
        return title.isDisplayed();
    }
}
