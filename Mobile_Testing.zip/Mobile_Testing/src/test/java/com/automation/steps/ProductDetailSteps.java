package com.automation.steps;

import com.automation.page.ProductDetailPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class ProductDetailSteps {

    ProductDetailPage productDetailPage = new ProductDetailPage();

    @Then("verify user is on the product detail page")
    public void verifyUserIsOnTheProductDetailPage() {
        Assert.assertTrue(productDetailPage.isProductDetailPAgeDisplayed());
    }

    @When("user enters the {string}, {string}, {string}, {string}, {string}, {string} details")
    public void userEntersTheDetails(String rightSph, String leftSph, String rightPower, String leftPower, String noOfBoxesRight, String noOfBoxesLeft) {
        productDetailPage.enterPowerDetails(rightSph, leftSph, rightPower, leftPower, noOfBoxesRight, noOfBoxesLeft);
    }

    @And("enters {string} and clicks on add to cart button")
    public void entersAndClicksOnAddToCartButton(String pinCode) {
        productDetailPage.enterPinCode(pinCode);
        productDetailPage.clickOnAddToCartBtn();
    }
}
