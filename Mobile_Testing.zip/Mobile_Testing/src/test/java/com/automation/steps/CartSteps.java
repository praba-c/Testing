package com.automation.steps;

import io.cucumber.java.en.Then;

public class CartSteps {

    @Then("verify user is on the cart page")
    public void verifyUserIsOnTheCartPage() {
    }
}
