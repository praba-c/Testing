package com.automation.steps;

import com.automation.page.ProductsPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class ProductsSteps {

    ProductsPage productsPage = new ProductsPage();

    @Then("verify user is on the products page")
    public void verifyUserIsOnTheProductsPage() {
        Assert.assertTrue(productsPage.isProductsPageDisplayed());
    }

    @When("user selects {string} from the product page")
    public void userSelectsFromTheProductPage(String productName) {
        productsPage.selectProduct(productName);

    }


}
