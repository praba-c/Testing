package com.automation.steps;

import com.automation.page.HomePage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class HomeSteps {
    HomePage homePage = new HomePage();
    @Given("user opens the application")
    public void userOpensTheApplication() {
        homePage.openApplication();
    }

    @Then("verify home page is displayed")
    public void verifyHomePageIsDisplayed() {
        Assert.assertTrue(homePage.isHomePageDisplayed());
    }

    @When("user selects the contact lenses")
    public void userSelectsTheContactLenses() {
        homePage.selectContactLenses();
    }
}
