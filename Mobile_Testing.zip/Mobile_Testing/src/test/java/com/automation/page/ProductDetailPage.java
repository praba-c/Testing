package com.automation.page;

import com.automation.utils.ConfigReader;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;

public class ProductDetailPage extends BasePage {

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.lenskart.app:id/text_title']")
    WebElement title;

    @FindBy(xpath = "//android.widget.RadioButton[@resource-id='com.lenskart.app:id/rb_ask_me_later']")
    WebElement uploadLaterBtn;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.lenskart.app:id/text_right_power_selector']")
    List<WebElement> rightEyeDetails;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.lenskart.app:id/text_left_power_selector']")
    List<WebElement> leftEyeDetails;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.lenskart.app:id/txt_Item']")
    List<WebElement> sphRightEye;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.lenskart.app:id/txt_Item']")
    List<WebElement> sphLeftEye;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.lenskart.app:id/txt_Item']")
    List<WebElement> powerRightEye;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.lenskart.app:id/txt_Item']")
    List<WebElement> powerLeftEye;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.lenskart.app:id/txt_Item']")
    List<WebElement> rightBoxes;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.lenskart.app:id/txt_Item']")
    List<WebElement> leftBoxes;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.lenskart.app:id/tv_label']")
    WebElement pinCodeTab;

    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.lenskart.app:id/edit_text']")
    WebElement pinCodeInputField;

    @FindBy(xpath = "//android.widget.Button[@resource-id='com.lenskart.app:id/btn_check']")
    WebElement checkBtn;

    @FindBy(xpath = "//android.widget.Button[@resource-id='com.lenskart.app:id/btn_add_to_cart']")
    WebElement addToCartBtn;

    public boolean isProductDetailPAgeDisplayed() {
        wait.until(ExpectedConditions.elementToBeClickable(title));
        return title.isDisplayed();
    }

    public void enterPowerDetails(String rightSph, String leftSph, String rightPower, String leftPower, String noOfBoxesRight, String noOfBoxesLeft) {

        while (!isDisplayed(uploadLaterBtn)) {
            scrollDown();
        }
        for (int i = 0;i<rightEyeDetails.size();++i) {
            if (i==0) {
                rightEyeDetails.get(i).click();
                for (WebElement sph : sphRightEye) {
                    if (sph.getText().equalsIgnoreCase(ConfigReader.getConfigValue(rightSph))) {
                        sph.click();
                        break;
                    }
                }
                leftEyeDetails.get(i).click();
                for (WebElement sph : sphLeftEye) {
                    if (sph.getText().equalsIgnoreCase(ConfigReader.getConfigValue(leftSph))) {
                        sph.click();
                        break;
                    }
                }
            }
            if (i == 2) {
                rightEyeDetails.get(i).click();
                for (WebElement power : powerRightEye) {
                    if (power.getText().equalsIgnoreCase(ConfigReader.getConfigValue(rightPower))) {
                        power.click();
                        break;
                    }
                }
                leftEyeDetails.get(i).click();
                for (WebElement power : powerLeftEye) {
                    if (power.getText().equalsIgnoreCase(ConfigReader.getConfigValue(leftPower))) {
                        power.click();
                        break;
                    }
                }
            }
            if (i==3) {
                rightEyeDetails.get(i).click();
                for (WebElement num : rightBoxes) {
                    if (num.getText().equalsIgnoreCase(ConfigReader.getConfigValue(noOfBoxesRight))) {
                        num.click();
                        break;
                    }
                }
                leftEyeDetails.get(i).click();
                for (WebElement num : leftBoxes) {
                    if (num.getText().equalsIgnoreCase(ConfigReader.getConfigValue(noOfBoxesLeft))) {
                        num.click();
                        break;
                    }
                }
            }
        }
    }

    public void enterPinCode(String inputPin) {
        while(!isPresent(pinCodeTab)){
            scrollDown();
        }
        pinCodeTab.click();
        pinCodeInputField.sendKeys(ConfigReader.getConfigValue(inputPin));
        checkBtn.click();
    }

    public void clickOnAddToCartBtn() {
        addToCartBtn.click();
    }
}
