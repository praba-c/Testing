package com.automation.page;

import com.automation.utils.ConfigReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class ProductsPage extends BasePage{

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.lenskart.app:id/text_title']")
    List<WebElement> products;

    public boolean isProductsPageDisplayed() {
        return !products.isEmpty();
    }

    public void selectProduct(String inputName) {
        for (WebElement product : products) {
            if (product.getText().contains(ConfigReader.getConfigValue(inputName))) {
                product.click();
                break;
            } else {
                scrollDown();
                products = driver.findElements(By.xpath("//android.widget.TextView[@resource-id='com.lenskart.app:id/text_title']"));
            }
        }
    }
}
