package com.automation.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class HomePage extends BasePage{

    @FindBy(xpath = "//android.widget.ImageView[@content-desc='Cancel']")
    WebElement googlePopupCloseBtn;

    @FindBy(xpath = "//android.widget.Button[@resource-id='com.lenskart.app:id/btnCta']")
    WebElement goToHomeBtn;

    @FindBy(xpath = "//android.widget.Button[@resource-id='com.android.permissioncontroller:id/permission_deny_button']")
    WebElement denyBtn;

    @FindBy(xpath = "//android.widget.ImageView[@resource-id='com.lenskart.app:id/iv_close']")
    WebElement frameSizeCloseBtn;

    @FindBy(xpath = "(//android.view.ViewGroup[@resource-id='com.lenskart.app:id/item_selection_ll'])[1]")
    WebElement homeTab;

    @FindBy(xpath = "(//androidx.recyclerview.widget.RecyclerView[@resource-id='com.lenskart.app:id/recyclerview'])[4]")
    WebElement contactLenses;

    @FindBy(xpath = "//android.widget.TextView[@text='Contact Lenses & Accessories']/../following-sibling::androidx.recyclerview.widget.RecyclerView/android.widget.FrameLayout")
    List<WebElement> contactLensesOptions;

    @FindBy(xpath = "(//android.widget.ImageView[@resource-id='com.lenskart.app:id/image'])")
    List<WebElement> availableContacts;

    public void openApplication() {
        googlePopupCloseBtn.click();
        goToHomeBtn.click();
        denyBtn.click();
        frameSizeCloseBtn.click();
    }

    public boolean isHomePageDisplayed() {
        return homeTab.isDisplayed();
    }

    public void selectContactLenses() {
        while (!isDisplayed(contactLenses)) {
            scrollDown();
        }
        contactLensesOptions.getFirst().click();
        availableContacts.get(2).click();
    }
}
