package com.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.automation.utils.ConfigReader;


public class HomePage extends BasePage{

    @FindBy (xpath = "//android.widget.TextView[@text='Select City']")
    WebElement selectCityBtn;

    @FindBy (xpath = "//android.widget.EditText[@text='Select city to book your ride']")
    WebElement searchBar;

    @FindBy (xpath = "//android.view.ViewGroup[@content-desc='TRIVANDRUM']")
    WebElement resultCity;

    @FindBy (xpath = "(//android.view.ViewGroup[@content-desc=' Date '])[1]")
    WebElement pickupDateTab;

    @FindBy (xpath = "//android.widget.TextView[@text='SEARCH']")
    WebElement searchBtn;

    String pickupDate = "//android.widget.TextView[@text='%s']";

    String pickupTime = "//android.widget.TextView[@text='%s']";

    String dropOffDate = "//android.widget.TextView[@text='%s']";

    String dropOffTime = "//android.widget.TextView[@text='%s']";


    public boolean isHomePageDisplayed() {
        return selectCityBtn.isDisplayed();
    }

    public void selectCity(String city) {
        selectCityBtn.click();
        searchBar.sendKeys(ConfigReader.getConfigValue(city));
        //resultCity.click();
    }

    public void selectDateAndTime(String pickDate, String pickTime, String dropDate, String dropTime) {
        pickupDateTab.click();

        String pickupDateXpath = String.format(pickupDate, ConfigReader.getConfigValue(pickDate));
        String pickupTimeXpath = String.format(pickupTime, ConfigReader.getConfigValue(pickTime));
        String dropOffDateXpath = String.format(dropOffDate, ConfigReader.getConfigValue(dropDate));
        String dropOffTimeXpath = String.format(dropOffTime, ConfigReader.getConfigValue(dropTime));

        System.out.println(pickupDateXpath);
        System.out.println(pickupTimeXpath);
        System.out.println(dropOffDateXpath);
        System.out.println(dropOffTimeXpath);

        driver.findElement(By.xpath(pickupDateXpath)).click();
        driver.findElement(By.xpath(pickupTimeXpath)).click();
        driver.findElement(By.xpath(dropOffDateXpath)).click();
        driver.findElement(By.xpath(dropOffTimeXpath)).click();
    }

    public void clickOnSearchBtn() {
        searchBtn.click();
    }


}
