package com.automation.pages;

import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends BasePage{

    @FindBy(xpath = "//android.widget.TextView[@text='Login or Signup']")
    WebElement loginOrSignUpCard;

    @FindBy(xpath = "//android.widget.EditText[@text='Enter Your Phone Number']")
    WebElement inputBar;

    @FindBy(xpath = "//android.widget.TextView[@text='GET OTP']")
    WebElement otpBtn;

    @FindBy(xpath = "//android.widget.TextView[@text='SUBMIT']")
    WebElement submitBtn;

    public boolean isLoginPageDisplayed() {
        return loginOrSignUpCard.isDisplayed();
    }

    public void enterNumber(String number) {
        inputBar.sendKeys(number);
    }

    public boolean verifyLogin() {
        otpBtn.click();
        otpBtn.click();
        return  submitBtn.isDisplayed();
    }
}
