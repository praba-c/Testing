package com.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class BikesPage extends BasePage{

    @FindBy(xpath = "//android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup")
    List<WebElement> bikes;

    @FindBy (xpath = "//android.view.ViewGroup[@content-desc='Kazhakootam Railway Station , (Front of Railway station,near Autostand)']")
    WebElement locations;

    @FindBy (xpath = "//android.widget.TextView[@text='BOOK NOW']")
    WebElement bookNowBtn;

    @FindBy(xpath = "//android.widget.TextView[@text='Select Pickup Location']")
    WebElement locationSelector;

    public boolean isBikesPageDisplayed() {
        return bikes.getFirst().isDisplayed();
    }

    public void listOfBikes() {

        int i = 0;
        while (i < 5) {

            for (WebElement bike : bikes) {
                scroll();
            }
            bikes = driver.findElements(By.xpath("//android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup"));
            i++;
        }
    }

    public void selectLocationAndBook() {
        locationSelector.click();
        locations.click();
        bookNowBtn.click();
    }

    public void printBikeNames() {
        System.out.println();
    }
}
