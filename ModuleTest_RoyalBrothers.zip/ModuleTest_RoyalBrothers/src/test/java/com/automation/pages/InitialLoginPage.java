package com.automation.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class InitialLoginPage extends BasePage{

    @FindBy(xpath = "//android.widget.TextView[@text='SKIP']")
    WebElement skipBtn;

    @FindBy(xpath = "//android.view.ViewGroup[@content-desc='SKIP']/com.horcrux.svg.SvgView/com.horcrux.svg.GroupView/com.horcrux.svg.PathView")
    WebElement skip;

    public void openApplication() {
    }

    public boolean isPageDisplayed() {
        wait.until(ExpectedConditions.elementToBeClickable(skipBtn));
        return skipBtn.isDisplayed();
    }

    public void skipTheInitialProcess() {
        skipBtn.click();
        skip.click();
    }
}
