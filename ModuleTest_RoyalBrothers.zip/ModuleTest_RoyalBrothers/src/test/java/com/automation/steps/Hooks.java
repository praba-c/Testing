package com.automation.steps;

import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import com.automation.utils.ConfigReader;
import com.automation.utils.DriverManger;
import com.automation.utils.Screenshot;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Hooks {

    @Before
    public void start() {
        ConfigReader.initConfig();
        DriverManger.createDriver();
    }

    @AfterStep
    public void attachScreenshot(Scenario scenario) {
        scenario.attach(Screenshot.takeScreenshot(DriverManger.getDriver()), "image/jpg", "Screenshot");
    }
    @After
    public void cleanUp(Scenario scenario) {

        if (scenario.isFailed()) {
            File file = new File("src/test/java/com/automation/screenshots");

            try (FileOutputStream fileOutputStream = new FileOutputStream(file) ) {
                fileOutputStream.write(Screenshot.takeScreenshot(DriverManger.getDriver()));
            }
            catch (Exception e) {

            }
        }
        DriverManger.getDriver().quit();
    }
}
