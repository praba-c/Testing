package com.automation.steps;

import io.cucumber.java.en.Given;
import com.automation.pages.InitialLoginPage;

public class InitialSteps {

    InitialLoginPage initialLoginPage = new InitialLoginPage();

    @Given("user opens the application")
    public void user_opens_the_application() {
        initialLoginPage.openApplication();
    }

    @Given("skip the initial login process")
    public void skip_the_initial_login_process() {
        initialLoginPage.skipTheInitialProcess();
    }
}
