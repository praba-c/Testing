package com.automation.steps;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import com.automation.pages.LoginPage;

public class LoginSteps {

    LoginPage loginPage = new LoginPage();

    @Then("verify login page is displayed")
    public void verify_login_page_is_displayed() {
        Assert.assertTrue(loginPage.isLoginPageDisplayed());
    }


    @When("user enters {string}")
    public void userEnters(String number) {
        loginPage.enterNumber(number);
    }

    @Then("verify entered numbers are valid")
    public void verifyEnteredNumbersAreValid() {
        Assert.assertTrue(loginPage.verifyLogin());
    }
}
