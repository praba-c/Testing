package com.automation.steps;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import com.automation.pages.BikesPage;

public class BikeSteps {

    BikesPage bikesPage = new BikesPage();

    @Then("verify list of bikes are displayed")
    public void verify_list_of_bikes_are_displayed() {
        Assert.assertTrue(bikesPage.isBikesPageDisplayed());
    }

    @When("user selects the pickup.point and clicks book now")
    public void user_selects_the_pickup_point_and_clicks_book_now() {
        bikesPage.selectLocationAndBook();
    }

    @When("user scrolls the bikes list")
    public void userScrollsTheBikesList() {
        bikesPage.scroll();
    }

    @Then("print the bike names")
    public void printTheBikeNames() {
        bikesPage.printBikeNames();
    }
}
