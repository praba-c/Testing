package com.automation.steps;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import com.automation.pages.HomePage;

public class HomeSteps {

    HomePage homePage = new HomePage();

    @Then("verify user is on the home page")
    public void verify_user_is_on_the_home_page() {
        Assert.assertTrue(homePage.isHomePageDisplayed());
    }

    @When("user selects the {string} as city from the listed cities")
    public void user_selects_the_as_city_from_the_listed_cities(String city) {
        homePage.selectCity(city);
    }

    @When("selects the {string}, {string} and {string}, {string}")
    public void selects_the_and(String pickupDate, String pickupTime, String dropOffDate, String dropOffTime) {
        homePage.selectDateAndTime(pickupDate, pickupTime, dropOffDate, dropOffTime);
    }

    @When("clicks on search button")
    public void clicks_on_search_button() {
        homePage.clickOnSearchBtn();
    }
}
